import { useState, useEffect } from "react";

function App() {
  const [tasks, setTasks] = useState([]);
  const [input, setInput] = useState("");
  const [editId, setEditId] = useState(null);

  useEffect(() => {
    const savedTasks = JSON.parse(localStorage.getItem("tasks"));
    if (savedTasks) setTasks(savedTasks);
  }, []);

  useEffect(() => {
    localStorage.setItem("tasks", JSON.stringify(tasks));
  }, [tasks]);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!input.trim()) return;

    if (editId) {
      const updated = tasks.map((task) =>
        task.id === editId ? { ...task, text: input } : task
      );
      setTasks(updated);
      setEditId(null);
      setInput("");
      return;
    }

    const newTask = {
      id: Date.now(),
      text: input,
      completed: false,
    };

    setTasks([...tasks, newTask]);
    setInput("");
  };

  const toggleComplete = (id) => {
    const updated = tasks.map((task) =>
      task.id === id ? { ...task, completed: !task.completed } : task
    );
    setTasks(updated);
  };

  const deleteTask = (id) => {
    setTasks(tasks.filter((task) => task.id !== id));
  };

  const editTask = (task) => {
    setInput(task.text);
    setEditId(task.id);
  };

  return (
    <div style={styles.wrapper}>
      <div style={styles.container}>
        <h1 style={styles.title}>React To-Do List</h1>

        <form onSubmit={handleSubmit} style={styles.form}>
          <input
            type="text"
            placeholder="Enter task..."
            value={input}
            onChange={(e) => setInput(e.target.value)}
            style={styles.input}
          />
          <button type="submit" style={styles.addButton}>
            {editId ? "Update" : "Add"}
          </button>
        </form>

        <ul style={styles.list}>
          {tasks.map((task) => (
            <li key={task.id} style={styles.listItem}>
              <span
                onClick={() => toggleComplete(task.id)}
                style={{
                  ...styles.taskText,
                  textDecoration: task.completed ? "line-through" : "none",
                  color: task.completed ? "#888" : "#000",
                }}
              >
                {task.text}
              </span>

              <div>
                <button onClick={() => editTask(task)} style={styles.editBtn}>
                  Edit
                </button>
                <button
                  onClick={() => deleteTask(task.id)}
                  style={styles.deleteBtn}
                >
                  Delete
                </button>
              </div>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}

/* Centering + clean UI */
const styles = {
  wrapper: {
    height: "100vh",
    width: "100%",
    display: "flex",
    justifyContent: "center",
    alignItems: "center", // centers vertically
    background: "linear-gradient(#cc95c0, #dbd4b4, #7aa1d2)",
  },
  container: {
    width: "450px",
    padding: "25px",
    borderRadius: "12px",
    background: "#ffffff",
    boxShadow: "0px 4px 12px rgba(0, 0, 0, 0.15)",
  },
  title: {
    textAlign: "center",
    marginBottom: "20px",
  },
  form: {
    display: "flex",
    gap: "10px",
  },
  input: {
    flex: 1,
    padding: "10px",
    fontSize: "16px",
    border: "1px solid #ccc",
    borderRadius: "6px",
  },
  addButton: {
    padding: "10px 20px",
    cursor: "pointer",
    borderRadius: "6px",
    background: "#6fd6d5ff",
    color: "white",
    border: "none",
  },
  list: {
    marginTop: "20px",
    padding: 0,
    listStyle: "none",
  },
  listItem: {
    background: "#f9f9f9",
    padding: "12px",
    marginBottom: "10px",
    borderRadius: "8px",
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
  },
  taskText: {
    cursor: "pointer",
    fontSize: "16px",
  },
  editBtn: {
    marginRight: "10px",
    padding: "6px 10px",
    cursor: "pointer",
  },
  deleteBtn: {
    padding: "6px 10px",
    cursor: "pointer",
    background: "#ff4d4d",
    color: "white",
    border: "none",
    borderRadius: "5px",
  },
};

export default App;
